// 전자책 판매용 활자 표지 + 3D 목업. 색면 · 괘선 · 사각 · 활자만 쓴다 (도형·일러스트·사진 없음).
//
//   node scripts/cover.mjs <표지.md> [--style 1|2|3|all] [--out 폴더] [--mockup] [--pdf 본문.pdf]
//
//   --style   1 밴드형  2 종이형  3 블록형  4 포스터형  5 하이라이트형  6 프레임형  all 전부 (SKILL.md 표 참고)
//   --mockup  스타일마다 3D 목업 PNG 도 만든다
//   --pdf     표지를 본문 PDF 1쪽에 붙인 "<이름>(표지포함).pdf" 를 만든다 (스타일 하나일 때)
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createCanvas, GlobalFonts } from "@napi-rs/canvas";
import { PDFDocument } from "pdf-lib";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const FONTS = path.join(HERE, "..", "assets", "fonts");
GlobalFonts.registerFromPath(path.join(FONTS, "Paperlogy-8ExtraBold.ttf"), "PL-XB");
GlobalFonts.registerFromPath(path.join(FONTS, "Paperlogy-7Bold.ttf"), "PL-B");
GlobalFonts.registerFromPath(path.join(FONTS, "Paperlogy-4Regular.ttf"), "PL-R");

// ── 입력 ──
export function readSpec(src) {
  const text = fs.readFileSync(src, "utf8").replace(/\r\n/g, "\n");
  const fm = text.match(/^---\n([\s\S]*?)\n---/);
  const meta = {};
  let last = null;
  for (const line of (fm ? fm[1] : text).split("\n")) {
    const m = line.match(/^([A-Za-z_]\w*):\s*(.*)$/);
    if (m) {
      const v = m[2].trim();
      meta[m[1]] = /^(["']).*\1$/.test(v) ? v.slice(1, -1) : v;   // 전체를 감싼 따옴표만 벗긴다
      last = m[1];
    } else if (last && /^\s+\S/.test(line)) meta[last] += "\n" + line.trim();  // 들여쓴 줄은 이어 붙인다
  }
  const lines = (v) => String(v || "").split("\n").map((s) => s.trim()).filter(Boolean);
  const [deep, accent, tint] = (meta.colors || "232B45 EE6C1F FDF3EC").split(/\s+/);
  return {
    hook: meta.hook || "",
    title: lines(meta.cover_title || meta.title),
    accent: meta.cover_accent || "",
    subtitle: String(meta.subtitle || "").replace(/\n/g, " "),
    parts: meta.cover_parts ? meta.cover_parts.split("|").map((s) => s.trim()).filter(Boolean) : [],
    author: meta.author || "",
    C: { deep: "#" + deep, accent: "#" + accent, tint: "#" + tint },
  };
}

// ── 활자 도구 ──
const W = 1296, H = 1944, M = 120, TW = W - M * 2;     // 6×9 판형, 216dpi
function kit(x) {
  const put = (t, px, py, size, face, color, ls = 0) => {
    x.font = `${size}px ${face}`; x.fillStyle = color; x.letterSpacing = ls + "px"; x.fillText(t, px, py);
  };
  /** 주어진 폭을 넘지 않는 가장 큰 크기 */
  const fit = (texts, face, max, width = TW) => Math.min(max, ...texts.map((t) => {
    x.font = `${max}px ${face}`; x.letterSpacing = -max * 0.04 + "px";
    return Math.floor(max * width / x.measureText(t).width);
  }));
  /** 폭에 맞춰 어절 단위로 줄을 나눈다 */
  const wrap = (t, size, face, width) => {
    x.font = `${size}px ${face}`; x.letterSpacing = "0px";
    const out = [];
    for (const w of t.split(" ")) {
      const cur = out.length ? out[out.length - 1] + " " + w : w;
      if (out.length && x.measureText(cur).width <= width) out[out.length - 1] = cur; else out.push(w);
    }
    return out;
  };
  const rect = (c, px, py, w, h) => { x.fillStyle = c; x.fillRect(px, py, w, h); };
  return { put, fit, wrap, rect };
}
const lum = (hex) => {
  const v = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255)
    .map((c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4));
  return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2];
};
/** 강조색이 바탕과 안 갈리면 대체색을 쓴다. 표지 강조는 큰 제목 글씨라 2.5:1 이면 충분히 읽힌다 */
const readable = (fg, bg, alt) => {
  const [a, b] = [lum(fg), lum(bg)].sort((p, q) => q - p);
  return (a + 0.05) / (b + 0.05) >= 2.5 ? fg : alt;
};

// ── 스타일 1: 밴드형 ── 짙은 바탕에 흰 큰 제목, 강조어는 강조색, 하단 옅은 띠에 구성
function band(x, d) {
  const { put, fit, wrap, rect } = kit(x);
  const acc = readable(d.C.accent, d.C.deep, d.C.tint);
  rect(d.C.deep, 0, 0, W, H);
  let y = 250;
  if (d.hook) { put(d.hook, M, y, fit([d.hook], "PL-B", 44), "PL-B", acc, -1); rect(acc, M, y + 50, 120, 8); y += 250; } else y = 380;
  const ts = fit(d.title, "PL-XB", 170);
  for (const ln of d.title) { put(ln, M, y, ts, "PL-XB", "#FFFFFF", -ts * 0.045); y += ts * 1.06; }
  if (d.accent) { const s = fit([d.accent], "PL-XB", 300); y += s * 0.62; put(d.accent, M, y, s, "PL-XB", acc, -s * 0.035); y += 120; } else y += 40;
  for (const ln of wrap(d.subtitle, 50, "PL-R", TW * 0.8)) { put(ln, M, y, 50, "PL-R", "#C9CEDC", -1); y += 70; }
  if (d.parts.length) {
    const BY = 1500, n = Math.min(d.parts.length, 4), cw = TW / n;
    rect(d.C.tint, 0, BY, W, H - BY);
    d.parts.slice(0, n).forEach((t, i) => {
      const px = M + i * cw;
      if (i) rect("rgba(0,0,0,0.12)", px - 26, BY + 95, 2, 230);
      put("PART " + (i + 1), px, BY + 140, 34, "PL-XB", d.C.accent, 2);
      wrap(t, 40, "PL-B", cw - 50).slice(0, 3).forEach((ln, k) => put(ln, px, BY + 225 + k * 60, 40, "PL-B", d.C.deep, -1));
    });
  }
  if (d.author) put(d.author, M, H - 70, 30, "PL-B", d.parts.length ? d.C.deep : "#C9CEDC");
}

// ── 스타일 2: 종이형 ── 밝은 바탕, 짙은 큰 제목, 굵은 괘선 두 줄 사이에 번호 목록
function paper(x, d) {
  const { put, fit, wrap, rect } = kit(x);
  const PAPER = "#F6F3EE", acc = readable(d.C.accent, PAPER, d.C.deep);
  rect(PAPER, 0, 0, W, H);
  rect(d.C.deep, M, 150, TW, 10);                                  // 위 굵은 괘선
  let y = 260;
  if (d.hook) { put(d.hook, M, y, fit([d.hook], "PL-B", 46), "PL-B", acc, -1); y += 210; } else y = 330;
  const ts = fit(d.title, "PL-XB", 172);
  for (const ln of d.title) { put(ln, M - 6, y, ts, "PL-XB", d.C.deep, -ts * 0.05); y += ts * 1.04; }
  if (d.accent) { const s = fit([d.accent], "PL-XB", 290); y += s * 0.6; put(d.accent, M - 8, y, s, "PL-XB", acc, -s * 0.04); y += 110; } else y += 40;
  for (const ln of wrap(d.subtitle, 48, "PL-R", TW)) { put(ln, M, y, 48, "PL-R", "#5B5F6B", -1); y += 66; }
  if (d.parts.length) {
    let py = Math.max(y + 60, H - 140 - d.parts.length * 96);
    rect(d.C.deep, M, py - 64, TW, 3);
    d.parts.slice(0, 4).forEach((t, i) => {
      put(String(i + 1).padStart(2, "0"), M, py, 40, "PL-XB", acc, 0);
      put(wrap(t, 40, "PL-B", TW - 110)[0], M + 100, py, 40, "PL-B", d.C.deep, -1);
      rect("rgba(0,0,0,0.12)", M, py + 34, TW, 2);
      py += 96;
    });
  }
  rect(d.C.deep, M, H - 120, TW, 10);                              // 아래 굵은 괘선
  if (d.author) put(d.author, M, H - 150, 30, "PL-B", d.C.deep);
}

// ── 스타일 3: 블록형 ── 위 60% 짙은 색면에 제목, 경계에 강조색 띠, 아래 흰 바탕에 큰 강조어와 구성 칩
function block(x, d) {
  const { put, fit, wrap, rect } = kit(x);
  const BY = 1150, acc = readable(d.C.accent, "#FFFFFF", d.C.deep);
  rect("#FFFFFF", 0, 0, W, H);
  rect(d.C.deep, 0, 0, W, BY);
  rect(d.C.accent, 0, BY, W, 22);
  const ts = fit(d.title, "PL-XB", 165);
  let y = BY - 110 - (d.title.length - 1) * ts * 1.06;
  if (d.hook) put(d.hook, M, y - ts - 70, fit([d.hook], "PL-B", 44), "PL-B", readable(d.C.accent, d.C.deep, d.C.tint), -1);
  for (const ln of d.title) { put(ln, M, y, ts, "PL-XB", "#FFFFFF", -ts * 0.045); y += ts * 1.06; }
  y = BY + 22;
  if (d.accent) { const s = fit([d.accent], "PL-XB", 260, TW * 0.6); y += s * 0.86 + 70; put(d.accent, M - 6, y, s, "PL-XB", acc, -s * 0.035); y += 90; }   // 띠와 붙지 않게 70 띄운다 else y += 120;
  for (const ln of wrap(d.subtitle, 46, "PL-R", TW * 0.85)) { put(ln, M, y, 46, "PL-R", "#3C4150", -1); y += 64; }
  if (d.parts.length) {
    const n = Math.min(d.parts.length, 3), gap = 24, cw = (TW - gap * (n - 1)) / n, cy = H - 290;
    d.parts.slice(0, n).forEach((t, i) => {
      const px = M + i * (cw + gap);
      rect(d.C.tint, px, cy, cw, 200);
      rect(d.C.accent, px, cy, cw, 8);
      put("PART " + (i + 1), px + 28, cy + 66, 28, "PL-XB", d.C.accent, 2);
      wrap(t, 34, "PL-B", cw - 56).slice(0, 2).forEach((ln, k) => put(ln, px + 28, cy + 120 + k * 48, 34, "PL-B", d.C.deep, -1));
    });
  }
  if (d.author) put(d.author, M, H - 50, 28, "PL-B", d.C.deep);
}

// ── 스타일 4: 포스터형 ── 강조색 전면, 강조어를 판 밖으로 잘려 나갈 만큼 거대하게. 제목은 짙은색
function poster(x, d) {
  const { put, fit, wrap, rect } = kit(x);
  const BG = d.C.accent, INK = readable(d.C.deep, BG, "#FFFFFF");
  rect(BG, 0, 0, W, H);
  if (d.accent) {                                        // 판 폭을 꽉 채우는 거대 강조어. 글자는 다 보이고 아래만 잘린다
    let s = 1000;
    x.font = `${s}px PL-XB`; x.letterSpacing = -s * 0.05 + "px";
    s = Math.floor(s * (W + 40) / x.measureText(d.accent).width);
    put(d.accent, -20, H + s * 0.1, s, "PL-XB", d.C.deep, -s * 0.05);
  }
  let y = 200;
  if (d.hook) { put(d.hook, M, y, fit([d.hook], "PL-B", 42), "PL-B", INK, -1); rect(INK, M, y + 44, TW, 4); y += 200; }
  const ts = fit(d.title, "PL-XB", 150, TW * 0.9);
  for (const ln of d.title) { put(ln, M, y, ts, "PL-XB", "#FFFFFF", -ts * 0.045); y += ts * 1.06; }
  y += 30;
  for (const ln of wrap(d.subtitle, 44, "PL-B", TW * 0.55)) { put(ln, M, y, 44, "PL-B", INK, -1); y += 62; }
  if (d.author) put(d.author, M, H - 90, 30, "PL-B", "#FFFFFF");
}

// ── 스타일 5: 하이라이트형 ── 밝은 바탕, 강조어 아래를 형광펜처럼 강조색 띠로 칠하고, 구성은 번호 사각 칸으로
function highlight(x, d) {
  const { put, fit, wrap, rect } = kit(x);
  const PAPER = "#FBFAF7";
  rect(PAPER, 0, 0, W, H);
  let y = 230;
  if (d.hook) { put(d.hook, M, y, fit([d.hook], "PL-B", 42), "PL-B", d.C.deep, -1); rect(d.C.deep, M, y + 40, TW, 3); y += 210; } else y = 330;
  const ts = fit(d.title, "PL-XB", 160);
  for (const ln of d.title) { put(ln, M, y, ts, "PL-XB", d.C.deep, -ts * 0.045); y += ts * 1.06; }
  if (d.accent) {
    const s = fit([d.accent], "PL-XB", 300, TW * 0.7);
    y += s * 0.66;
    x.font = `${s}px PL-XB`; x.letterSpacing = -s * 0.035 + "px";
    const w = x.measureText(d.accent).width;
    rect(d.C.accent, M - 20, y - s * 0.34, w + 50, s * 0.4);   // 글자 아래쪽 절반을 지나는 형광펜 띠
    put(d.accent, M, y, s, "PL-XB", d.C.deep, -s * 0.035);
    y += 110;
  } else y += 40;
  for (const ln of wrap(d.subtitle, 46, "PL-R", TW)) { put(ln, M, y, 46, "PL-R", "#4A4E5A", -1); y += 64; }
  if (d.parts.length) {
    let py = H - 160 - (Math.min(d.parts.length, 4) - 1) * 100;
    d.parts.slice(0, 4).forEach((t, i) => {
      rect(d.C.accent, M, py - 46, 60, 60);
      x.font = "36px PL-XB"; x.letterSpacing = "0px"; x.fillStyle = "#FFFFFF"; x.textAlign = "center";
      x.fillText(String(i + 1), M + 30, py - 2); x.textAlign = "left";
      put(wrap(t, 40, "PL-B", TW - 100)[0], M + 90, py - 2, 40, "PL-B", d.C.deep, -1);
      py += 100;
    });
  }
  if (d.author) put(d.author, W - M - 200, 120, 28, "PL-B", d.C.deep);
}

// ── 스타일 6: 프레임형 ── 짙은 바탕에 가는 안쪽 테두리, 모두 가운데 정렬, 강조어는 외곽선 글자
function frame(x, d) {
  const { fit, wrap, rect } = kit(x);
  const acc = readable(d.C.accent, d.C.deep, d.C.tint);
  rect(d.C.deep, 0, 0, W, H);
  x.strokeStyle = acc; x.lineWidth = 4; x.strokeRect(64, 64, W - 128, H - 128);
  const center = (t, y, size, face, color, ls = 0) => {
    x.font = `${size}px ${face}`; x.letterSpacing = ls + "px"; x.fillStyle = color; x.textAlign = "center";
    x.fillText(t, W / 2, y); x.textAlign = "left";
  };
  let y = 280;
  if (d.hook) { center(d.hook, y, fit([d.hook], "PL-B", 40, TW * 0.9), "PL-B", acc, 2); rect(acc, W / 2 - 40, y + 50, 80, 4); y += 230; }
  const ts = fit(d.title, "PL-XB", 150, TW * 0.92);
  for (const ln of d.title) { center(ln, y, ts, "PL-XB", "#FFFFFF", -ts * 0.04); y += ts * 1.08; }
  if (d.accent) {
    const s = fit([d.accent], "PL-XB", 380, TW * 0.8);
    y += s * 0.72;
    x.font = `${s}px PL-XB`; x.letterSpacing = -s * 0.03 + "px"; x.textAlign = "center";
    x.lineWidth = 6; x.strokeStyle = acc; x.strokeText(d.accent, W / 2, y); x.textAlign = "left";
    y += 110;
  } else y += 40;
  for (const ln of wrap(d.subtitle, 44, "PL-R", TW * 0.9)) { center(ln, y, 44, "PL-R", "#C9CEDC", -1); y += 62; }
  if (d.parts.length) {
    const line = d.parts.join("  ·  ");
    center(line, H - 170, fit([line], "PL-B", 32, TW * 0.92), "PL-B", "#FFFFFF");
  }
  if (d.author) center(d.author, H - 110, 28, "PL-B", acc);
}

export const STYLES = {
  1: ["밴드형", band], 2: ["종이형", paper], 3: ["블록형", block],
  4: ["포스터형", poster], 5: ["하이라이트형", highlight], 6: ["프레임형", frame],
};

export function drawCover(d, style) {
  const c = createCanvas(W, H);
  STYLES[style][1](c.getContext("2d"), d);
  return c;
}

// ── 3D 목업 ──
export function drawMockup(cover, d) {
  const MW = 2400, MH = 1800, m = createCanvas(MW, MH), g = m.getContext("2d");
  const bg = g.createLinearGradient(0, 0, 0, MH);
  bg.addColorStop(0, "#EEEAE4"); bg.addColorStop(1, "#D8D2C9");
  g.fillStyle = bg; g.fillRect(0, 0, MW, MH);
  const bh = 1380, bw = Math.round(bh * W / H), spine = 70, shrink = 0.035;
  const bx = Math.round((MW - bw + spine) / 2), by = Math.round((MH - bh) / 2);
  g.save(); g.filter = "blur(40px)"; g.fillStyle = "rgba(40,30,20,0.45)";
  g.fillRect(bx - spine + 40, by + bh - 30, bw + 40, 60); g.fillRect(bx + bw - 20, by + 60, 50, bh - 60); g.restore();
  // 책등
  g.beginPath();
  g.moveTo(bx - spine, by + 18); g.lineTo(bx, by); g.lineTo(bx, by + bh); g.lineTo(bx - spine, by + bh - 18); g.closePath();
  g.fillStyle = d.C.deep; g.fill(); g.fillStyle = "rgba(0,0,0,0.28)"; g.fill();
  // 책등 제목: 글자 높이의 가운데를 책등 가운데에 맞춘다 (baseline 에 두면 윗부분이 앞표지에 덮여 잘린다)
  const head = d.title.join(" ") + (d.accent ? " " : "");
  let ss = Math.round(spine * 0.46);
  g.font = `${ss}px PL-B`;
  const sw = g.measureText(head + d.accent).width;
  if (sw > bh * 0.8) { ss = Math.floor(ss * bh * 0.8 / sw); g.font = `${ss}px PL-B`; }
  g.save(); g.translate(bx - spine / 2, by + 110); g.rotate(Math.PI / 2); g.textBaseline = "middle";
  g.fillStyle = "#FFFFFF"; g.fillText(head, 0, 0);
  if (d.accent) { g.fillStyle = readable(d.C.accent, d.C.deep, d.C.tint); g.fillText(d.accent, g.measureText(head).width, 0); }
  g.restore();
  // 앞표지: 세로 띠로 잘라 오른쪽으로 갈수록 높이를 줄여 원근감을 준다
  for (let sx = 0; sx < bw; sx += 2) {
    const hh = bh * (1 - shrink * (sx / bw));
    g.drawImage(cover, (sx / bw) * W, 0, (2 / bw) * W + 1, H, bx + sx, by + (bh - hh) / 2, 2.6, hh);
  }
  const hl = g.createLinearGradient(bx, 0, bx + 60, 0);
  hl.addColorStop(0, "rgba(0,0,0,0.35)"); hl.addColorStop(0.3, "rgba(255,255,255,0.18)"); hl.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = hl; g.fillRect(bx, by, 60, bh);
  const sh = g.createLinearGradient(bx, by, bx + bw, by + bh);
  sh.addColorStop(0, "rgba(255,255,255,0.10)"); sh.addColorStop(0.5, "rgba(255,255,255,0)"); sh.addColorStop(1, "rgba(0,0,0,0.12)");
  g.fillStyle = sh; g.beginPath();
  g.moveTo(bx, by); g.lineTo(bx + bw, by + bh * shrink / 2); g.lineTo(bx + bw, by + bh - bh * shrink / 2); g.lineTo(bx, by + bh);
  g.closePath(); g.fill();
  return m;
}

// ── 실행 ──
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const argv = process.argv.slice(2);
  const opt = (k) => { const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : null; };
  const src = argv.find((a, i) => !a.startsWith("--") && !(argv[i - 1] || "").match(/^--(style|out|pdf)$/));
  if (!src) { console.error("사용법: node scripts/cover.mjs 표지.md [--style 1|2|3|all] [--out 폴더] [--mockup] [--pdf 본문.pdf]"); process.exit(1); }
  const d = readSpec(src);
  const want = opt("--style") || "1";
  const styles = want === "all" ? Object.keys(STYLES) : [want];
  const outDir = opt("--out") || path.dirname(path.resolve(src));
  fs.mkdirSync(outDir, { recursive: true });
  for (const s of styles) {
    const [name] = STYLES[s];
    const cover = drawCover(d, s);
    const png = cover.toBuffer("image/png");
    const base = styles.length > 1 ? `표지_${s}_${name}` : "표지";
    fs.writeFileSync(path.join(outDir, base + ".png"), png);
    console.log("완성: " + path.join(outDir, base + ".png"));
    if (argv.includes("--mockup")) {
      const mp = path.join(outDir, base.replace("표지", "3D목업") + ".png");
      fs.writeFileSync(mp, drawMockup(cover, d).toBuffer("image/png"));
      console.log("완성: " + mp);
    }
    if (opt("--pdf") && styles.length === 1) {
      const body = await PDFDocument.load(fs.readFileSync(opt("--pdf")));
      const { width, height } = body.getPage(0).getSize();
      const out = await PDFDocument.create();
      out.addPage([width, height]).drawImage(await out.embedPng(png), { x: 0, y: 0, width, height });
      (await out.copyPages(body, body.getPageIndices())).forEach((p) => out.addPage(p));
      out.setTitle(d.title.join(" ") + (d.accent ? " " + d.accent : ""));
      out.setLanguage("ko-KR");
      const dst = opt("--pdf").replace(/\.pdf$/i, "(표지포함).pdf");
      fs.writeFileSync(dst, await out.save());
      console.log("완성: " + dst);
    }
  }
}
